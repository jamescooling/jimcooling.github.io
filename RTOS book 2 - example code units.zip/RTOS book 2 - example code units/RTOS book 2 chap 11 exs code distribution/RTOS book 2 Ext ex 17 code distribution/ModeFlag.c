 /*
  File name: ModeFlag.c
  Version: 1.0   Date: 4/3/20  Author: JEC
*/

#include "ModeFlag.h"
// IMPORTANT NOTE  -  THESE ITEMS NEED TO BE DECLARED AT FILE LEVEL
static Flag    ModeFlag = ResetToMode1;

/*----------------------------------------------------------------------------*/

void MO_SetFlagToMode2(void)
{
	ModeFlag = SetToMode2;
    
} /*end SetModeFlag */
////////////////////////////////////////////////////////////////////////////////

void MO_ResetFlagToMode1(void)
{
    ModeFlag = ResetToMode1;
    
} /*end ResetModeFlag */
////////////////////////////////////////////////////////////////////////////////


Flag MO_StatusOfModeFlag(void)
{
    return ModeFlag;
    
} /*end ResetCoordinatingFlag1 */
////////////////////////////////////////////////////////////////////////////////





