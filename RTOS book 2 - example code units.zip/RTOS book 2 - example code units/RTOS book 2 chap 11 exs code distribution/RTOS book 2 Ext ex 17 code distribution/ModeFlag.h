/* 
  File name:ModeFlag.h
  Version: 1.0   Date: 10/1/21  Author: JEC
*/

#ifndef ModeFlag_H
#define ModeFlag_H

#include "stm32f4xx_hal.h"

typedef enum {SetToMode2, ResetToMode1} Flag;

void MO_SetFlagToMode2(void);

void MO_ResetFlagToMode1(void);

Flag MO_StatusOfModeFlag(void);

#endif


