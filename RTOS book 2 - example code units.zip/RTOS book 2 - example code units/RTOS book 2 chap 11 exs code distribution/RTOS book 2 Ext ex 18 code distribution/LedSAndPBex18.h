/* 
  File name: LedsAndPBex18.h
  Version: 2.0   Date: 10/1/21  Author: JEC
*/

#ifndef LedsAndPBex18_H
#define LedsAndPBex18_H

#include "main.h"
#include "stm32f4xx_hal.h"
//#include "cmsis_os.h"

#define ToggleRedLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_14))
#define ToggleBlueLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15))
#define ToggleGreenLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_12))
#define ToggleOrangeLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_13))

#define TurnRedLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_SET))
#define TurnBlueLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_SET))
#define TurnGreenLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET))
#define TurnOrangeLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET))

#define TurnRedLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_RESET))
#define TurnBlueLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_RESET))
#define TurnGreenLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET))
#define TurnOrangeLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET))


#define ButtonIsReleased (GPIO_PIN_RESET)
#define ButtonIsPressed (GPIO_PIN_SET)

/******************** NOTE  --  THIS IS NEW ***************************************/

#define UserPBstatus (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0))
#define UserPBisPressed (UserPBstatus == ButtonIsPressed)
#define UserPBisReleased (UserPBstatus == ButtonIsReleased)

/* NOTE: This is in file stm32f4xx_hal_gpio.h
typedef enum
{
  GPIO_PIN_RESET = 0,
  GPIO_PIN_SET
}GPIO_PinState;
*/


#endif
