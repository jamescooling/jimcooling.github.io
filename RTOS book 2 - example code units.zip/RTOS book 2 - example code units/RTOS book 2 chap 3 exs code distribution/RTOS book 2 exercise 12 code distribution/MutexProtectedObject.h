/* 
  File name: MutexProtectedObject.h
  Version: 2.0   Date: 15/12/20  Author: JEC
*/

#ifndef MutexProtectedObject_H
#define MutexProtectedObject_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "main.h"
#include "LedsAndPB.h"

// The prefix MPO is used to identify the exporting file.
#define MPO_ByRedTask 1
#define MPO_ByGreenTask 3

// This performs the role of a mutex-protected shared data store
void MPO_AccessSharedData(int Task);
/* Task = 1 for Red, 3 for Green */

#endif


