/* 
  File name: MutexObject.c  for the STM32 board work
  Version: 2.0   Date: 15/12/20  Author: JEC
*/

#include "MutexProtectedObject.h"

/* definition and creation of semaphore handle CriticalResourceSemaphore */
SemaphoreHandle_t 	CriticalResourceMutex;

enum MutexState {NotCreated, Created};
static enum MutexState 	MutexStatus = NotCreated;
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
void  MPO_AccessSharedData(int Task)
{
	int CountHere = 0;
	int ToggleLed = 0;
	const int WaitLong = 10000;

	// Ensure that the semaphore is created
	if (MutexStatus == NotCreated)
	{
        /* Create the mutex */
        CriticalResourceMutex = xSemaphoreCreateMutex();
        xSemaphoreGive (CriticalResourceMutex);
        MutexStatus = Created;
	}// end if
    
  	xSemaphoreTake (CriticalResourceMutex, WaitLong);    
	// Start of the critical code section
	// This is a 2 second period of led toggling to simulate execution of the task code
	for (ToggleLed=0; ToggleLed<=20; ToggleLed++)
	{
		for (CountHere=0; CountHere<=2000000; CountHere++)
			{ ; };// 50 millisecond loop						
        TurnBlueLedOn;
        if (Task == MPO_ByRedTask) 
					{TurnRedLedOn;}
        else if (Task == MPO_ByGreenTask) 
					{TurnGreenLedOn;}
				else {;}
					
		for (CountHere=0; CountHere<=2000000; CountHere++)
			{ ; };// 50 millisecond loop						
        TurnBlueLedOff;
        if (Task == MPO_ByRedTask) 
					{TurnRedLedOff;}
        else if (Task == MPO_ByGreenTask) 
					{TurnGreenLedOff;}
				else {;}
	}	// end 	ToggleLed loop
	// End of the critical code section
  	xSemaphoreGive (CriticalResourceMutex);	      
} /*end AccessSharedData */

//////////////////////////////////////////////////////////////////////////////////////



 
 
