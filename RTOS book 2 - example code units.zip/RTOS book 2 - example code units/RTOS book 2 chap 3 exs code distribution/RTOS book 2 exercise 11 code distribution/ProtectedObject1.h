/* 
  File name: ProtectedObject1.h
  Version: 2.0   Date: 14/12/20  Author: JEC
	The combination of the .h and .c files are used to implement a module
	which holds the protected object.
*/

#ifndef ProtectedObject1_H
#define ProtectedObject1_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "main.h"
#include "LedsAndPB.h"


// The prefix PO is used to identify the exporting file.
#define PO_ByRedTask 1
#define PO_ByGreenTask 3

// This performs the role of a semaphore-protected shared data store
void PO_AccessProtectedObject (int CallingTask);

#endif


