/* 
  File name: ProtectedObject1.c  for the STM32 board work
  Version: 2.0   Date: 15/12/20  Author: JEC
  This original ProtectedObject code has been modified to include switching
  of the Green and Red Leds.  
	http://www.freertos.org/xSemaphoreCreateBinary.html
*/

#include "ProtectedObject1.h"

/*-----------------------Variables and constants------------------------------*/


/* definition and creation of semaphore handle CriticalResourceSemaphore */
SemaphoreHandle_t 	CriticalResourceSemaphore;

enum SemaState {NotCreated, Created};
enum SemaState 	SemaphoreState = NotCreated;
/*----------------------------------------------------------------------------*/

void  PO_AccessProtectedObject(int CallingTask)
{
	int CountHere = 0;
	int ToggleLed = 0;
	const int	WaitLong = 10000;

	// Ensure that the semaphore is created
	if (SemaphoreState == NotCreated)
	{
	   	/* Create the semaphores(s) */
    	CriticalResourceSemaphore = xSemaphoreCreateBinary();
    	SemaphoreState = Created;
    	xSemaphoreGive (CriticalResourceSemaphore);					
			SemaphoreState = Created;		
	}// end if
	
	
  xSemaphoreTake (CriticalResourceSemaphore, WaitLong);
	// Start of the critical code section
	// This is a 2 second period of led toggling to simulate execution of the task code		
	for (ToggleLed=0; ToggleLed<=20; ToggleLed++)
	{
		for (CountHere=0; CountHere<=2000000; CountHere++)
			{ ; };// 50 millisecond loop						
		TurnBlueLedOn;			
    if (CallingTask == PO_ByRedTask) 
			{TurnRedLedOn;}
		else if (CallingTask == PO_ByGreenTask) 
			{TurnGreenLedOn;}
		else {;}				
		for (CountHere=0; CountHere<=2000000; CountHere++)
			{ ; };// 50 millisecond loop						
		TurnBlueLedOff;
		if (CallingTask == PO_ByRedTask) 
			{TurnRedLedOff;}
		else if (CallingTask == PO_ByGreenTask) 
			{TurnGreenLedOff;}
		else {;}			
	}	// end 	ToggleLed loop			
	// End of the critical code section
  xSemaphoreGive (CriticalResourceSemaphore);	      
} /*end PO_AccessProtectedObject */

/////////////////////////////////////////////////////////////////////////////////////////////////////////



 
 
