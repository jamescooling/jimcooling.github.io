/* 
  File name: WDTFlagObject.h
  Version: 1.0   Date: 10/1/21  Author: JEC
*/

#ifndef WDTFlagObject_H
#define WDTFlagObject_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"

typedef enum {Raise, Lower} Flag;

void WD_RaiseStartFlag(void);
void WD_RaiseFinishFlag(void);
void WD_LowerStartFlag(void);
void WD_LowerFinishFlag(void);

Flag WD_StatusOfStartFlag(void);
Flag WD_StatusOfFinishFlag(void);
#endif


