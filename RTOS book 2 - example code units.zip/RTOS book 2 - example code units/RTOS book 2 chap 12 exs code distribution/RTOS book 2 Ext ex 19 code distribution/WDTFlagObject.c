 /*
  File name: WDTFlagObject.c
  Version: 1.0   Date: 10/1/21  Author: JEC
*/

#include "WDTFlagObject.h"

// IMPORTANT NOTE  -  THESE ITEMS NEED TO BE DECLARED AT FILE LEVEL
static Flag    StartFlag = Lower;
static Flag    FinishFlag = Lower;
/*----------------------------------------------------------------------------*/

void WD_RaiseStartFlag(void)
{
	StartFlag = Raise;
    
} /* end RaiseStartFlag */
////////////////////////////////////////////////////////////////////////////////

void WD_RaiseFinishFlag(void)
{
    FinishFlag = Raise;
    
} /* end RaiseFinishFlag */
////////////////////////////////////////////////////////////////////////////////

void WD_LowerStartFlag(void)
{
    StartFlag = Lower;
    
} /* end LowerStartFlag */
////////////////////////////////////////////////////////////////////////////////

void WD_LowerFinishFlag(void)
{
    FinishFlag = Lower;
    
} /* end LowerFinishFlag */
////////////////////////////////////////////////////////////////////////////////

Flag WD_StatusOfStartFlag(void)
{
    return StartFlag;
    
} /* end StatusOfStartFlag */
////////////////////////////////////////////////////////////////////////////////

Flag WD_StatusOfFinishFlag(void)
{
    return FinishFlag;
    
} /* end StatusOfFinishFlag */
////////////////////////////////////////////////////////////////////////////////



