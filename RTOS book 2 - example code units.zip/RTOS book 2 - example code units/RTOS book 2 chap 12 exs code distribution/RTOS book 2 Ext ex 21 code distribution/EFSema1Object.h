/* 
  File name: EFSema1Object.h
  Version: 2.1   Date: 12/1/21  Author: JEC
*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "LedsAndPBex21.h"

#ifndef EFSema1Object_H
#define EFSema1Object_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"



void EF_CreateEFSema1 (void);

void EF_SetEFSema1 (void);

void EF_WaitEFSema1 (void);

#endif


