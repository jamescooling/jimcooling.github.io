 /* 
  File name:    EFSema1Object.c
  Version: 2.1   Date: 12/1/21  Author: JEC
*/

#include "EFSema1Object.h"
/* ==== NOTE NOTE NOTE == MODULE GLOBALS == GLOBALS GLOBALS ==== */

#define WaitForever		portMAX_DELAY
#define Blocked  	1
#define NoWaiting 0

enum SemaState {SemaNotCreated, SemaCreated};
static enum SemaState    EFSemaState = SemaNotCreated;

/* Definition of the semaphore */
SemaphoreHandle_t EFSema1 	= NULL;

/* === EndGlobals EndGlobals EndGlobals EndGlobals EndGlobals === */


/* ========================================================================== */
/* ========================================================================== */

void EF_CreateEFSema1 (void)
{
	/* Create the semaphore */
	EFSemaState = SemaCreated;
	/*Initialize the semaphores to a blocked state */
	EFSema1 = xSemaphoreCreateBinary();	
} /* end CreateEFSema */
/* ========================================================================== */
/* ========================================================================== */

void EF_SetEFSema1 (void)
{
	if (EFSemaState == SemaNotCreated)
	{
		EF_CreateEFSema1();
	}
	xSemaphoreGiveFromISR(EFSema1, NULL);
	TurnBlueLedOn;
} /* end SetEFSema */
/* ========================================================================== */


void EF_WaitEFSema1 (void)
{
	if (EFSemaState == SemaNotCreated)
	{
		EF_CreateEFSema1();
	}	
	xSemaphoreTake (EFSema1, WaitForever); 	// wait on semaphore 1      
} /* end WaitEFSema  */
/* ========================================================================== */



