/* 
  File name: FlagObjects.h
  Version: 2.0   Date: 11/1/21  Author: JEC
*/

#ifndef FlagObjects_H
#define FlagObjects_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"

typedef enum {Raise, Lower} Flag;

void FL_RaiseStartFlag1(void);
void FL_RaiseFinishFlag1(void);
void FL_LowerStartFlag1(void);
void FL_LowerFinishFlag1(void);
Flag FL_StatusOfStartFlag1(void);
Flag FL_StatusOfFinishFlag1(void);


void FL_RaiseStartFlag2(void);
void FL_RaiseFinishFlag2(void);
void FL_LowerStartFlag2(void);
void FL_LowerFinishFlag2(void);
Flag FL_StatusOfStartFlag2(void);
Flag FL_StatusOfFinishFlag2(void);


#endif


