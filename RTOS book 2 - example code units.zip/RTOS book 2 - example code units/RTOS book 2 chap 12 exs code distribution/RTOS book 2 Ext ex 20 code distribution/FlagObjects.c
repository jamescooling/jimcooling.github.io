 /*
  File name: FlagObjects.c
  Version: 2.0   Date: 11/1/21  Author: JEC
*/

#include "FlagObjects.h"

// IMPORTANT NOTE FOR ME  -  THESE ITEMS NEED TO BE DECLARED AT FILE LEVEL
static Flag    StartFlag1 = Lower;
static Flag    FinishFlag1 = Lower;

static Flag    StartFlag2 = Lower;
static Flag    FinishFlag2 = Lower;
/*----------------------------------------------------------------------------*/

void FL_RaiseStartFlag1(void)
{
	StartFlag1 = Raise;
    
} /* end RaiseStartFlag1 */
////////////////////////////////////////////////////////////////////////////////

void FL_RaiseFinishFlag1(void)
{
    FinishFlag1 = Raise;
    
} /* end 1 */
////////////////////////////////////////////////////////////////////////////////

void FL_LowerStartFlag1(void)
{
    StartFlag1 = Lower;
    
} /* end LowerStartFlag1 */
////////////////////////////////////////////////////////////////////////////////

void FL_LowerFinishFlag1(void)
{
    FinishFlag1 = Lower;
    
} /* end LowerFinishFlag1 */
////////////////////////////////////////////////////////////////////////////////

Flag FL_StatusOfStartFlag1(void)
{
    return StartFlag1;
    
} /* end StatusOfStartFlag1 */
////////////////////////////////////////////////////////////////////////////////

Flag FL_StatusOfFinishFlag1(void)
{
    return FinishFlag1;
    
} /* end StatusOfFinishFlag1 */
////////////////////////////////////////////////////////////////////////////////

void FL_RaiseStartFlag2(void)
{
    StartFlag2 = Raise;
    
} /* end RaiseStartFlag */
////////////////////////////////////////////////////////////////////////////////

void FL_RaiseFinishFlag2(void)
{
    FinishFlag2 = Raise;
    
} /* end RaiseFinishFlag */
////////////////////////////////////////////////////////////////////////////////

void FL_LowerStartFlag2(void)
{
    StartFlag2 = Lower;
    
} /* end LowerStartFlag */
////////////////////////////////////////////////////////////////////////////////

void FL_LowerFinishFlag2(void)
{
    FinishFlag2 = Lower;
    
} /* end LowerFinishFlag */
////////////////////////////////////////////////////////////////////////////////

Flag FL_StatusOfStartFlag2(void)
{
    return StartFlag2;
    
} /* end StatusOfStartFlag */
////////////////////////////////////////////////////////////////////////////////

Flag FL_StatusOfFinishFlag2(void)
{
    return FinishFlag2;
    
} /* end StatusOfFinishFlag */
////////////////////////////////////////////////////////////////////////////////





