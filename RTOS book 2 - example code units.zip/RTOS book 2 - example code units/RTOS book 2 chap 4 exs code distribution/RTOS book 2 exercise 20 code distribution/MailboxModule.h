/* 
  File name: MailboxModule.h
  Version: 2.0   Date: 24/12/20  Author: JEC
*/

#ifndef MailboxModule_H		/*module designator MB */
#define MailboxModule_H

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "LedsAndPB.h"

   void MB_PendOnMailbox (int* pIncomingMessage);

   void MB_PostToMailbox (int OutgoingMessage);
	 
	 void CreateGlobalmailMBox (void);

#endif

