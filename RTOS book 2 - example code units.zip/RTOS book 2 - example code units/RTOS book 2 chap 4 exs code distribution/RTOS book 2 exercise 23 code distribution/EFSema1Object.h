/* 
  File name: EFSema1Object.h
  Version: 1.0   Date: 20/4/17  Author: JEC
*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "LedsAndPB.h"

#ifndef EFSema1Object_H
#define EFSema1Object_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"



void EFcreateEFSema1 (void);

void EFsetEFSema1 (void);

void EFwaitEFSema1 (void);

#endif


