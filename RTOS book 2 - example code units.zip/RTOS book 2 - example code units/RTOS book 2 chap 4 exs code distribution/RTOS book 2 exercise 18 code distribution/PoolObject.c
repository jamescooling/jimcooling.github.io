 /* 
  File name: PoolObject.c
  Version: 2.0   Date: 19/12/20  Author: JEC
	WARNING: Non-portable code
*/

#include "PoolObject.h"

/*--------------------------------Data types----------------------------------*/

enum SemaState {NotCreated, Created};

typedef struct
{
    int GreenTaskFlashRate;
    float RedTaskFlashRate;
}
FlashingRate;

/*----------------------------------------------------------------------------*/
/*-----------------------Variables and constants------------------------------*/
/*  WARNING  WARNING WARNING  -- THESE ARE GLOBAL TO THE FILE AND ARE ACCESSED 
		AS NEEDED IN THE PROGRAM UNIT 
*/
#define WaitForever		portMAX_DELAY

/* definition and creation of semaphore handle CriticalResourceSemaphore */
SemaphoreHandle_t 	CriticalResourceSemaphore;
static enum SemaState 	SemaphoreState = NotCreated;

static FlashingRate  FlashingDataPool = {10, 1};  // default flashing rates.
/*----------------------------------------------------------------------------*/
/*---------------------------Function prototypes------------------------------*/
void CreateCriticalResourceSemaphore(void);
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
void  PO_SetFlashingRate(int TaskColour, int FlashRate)

/* IMPORTANT NOTE: All the file Globals used here - ALL OF THEM */
{
    // Ensure that the semaphore is created
    if (SemaphoreState == NotCreated)
    {
        CreateCriticalResourceSemaphore();
        SemaphoreState = Created;
    }// end if
    
    xSemaphoreTake (CriticalResourceSemaphore, portMAX_DELAY);
    // Start of the critical code section	
		if (TaskColour == Green)
		{
			FlashingDataPool.GreenTaskFlashRate = FlashRate;				
		}
		else if (TaskColour == Red)
		{
			FlashingDataPool.RedTaskFlashRate = FlashRate;
		}
		else
		{
			;
		} // end if-else  
    // End of the critical code section
    xSemaphoreGive (CriticalResourceSemaphore);
    
}/*end PO_SetFlashingRate */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
void  PO_GetFlashingRate(int TaskColour, int* FlashRateRef)

/* Note: the flashing rate value is returned as a parameter because a return 
statement terminates a function  -  hence cannot be placed before the xSemaphoreGive 
statement.  In a case like that the actual return action would NOT be within the protected code
*/
/* IMPORTANT NOTE: All the file globals are used here - ALL OF THEM */
{
    // Ensure that the semaphore is created
    if (SemaphoreState == NotCreated)
    {
        CreateCriticalResourceSemaphore();
        SemaphoreState = Created;
    }// end if
    
    xSemaphoreTake (CriticalResourceSemaphore, portMAX_DELAY);
    // Start of the critical code section
		if (TaskColour == Green)
		{
			*FlashRateRef = FlashingDataPool.GreenTaskFlashRate;	
		}
		else if (TaskColour == Red)
		{
			*FlashRateRef = FlashingDataPool.RedTaskFlashRate;
		}
		else
		{
			;// put a raise exception here
		} // end if else TC
     xSemaphoreGive (CriticalResourceSemaphore); 

    // End of the critical code section
}/* end PO_GetFlashingRate*/

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

void CreateCriticalResourceSemaphore(void)
{
    /* Create the semaphores(s) */
    CriticalResourceSemaphore = xSemaphoreCreateBinary();
    SemaphoreState = Created;
    xSemaphoreGive (CriticalResourceSemaphore);
} // end 	CreateCriticalResourceSemaphore

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


