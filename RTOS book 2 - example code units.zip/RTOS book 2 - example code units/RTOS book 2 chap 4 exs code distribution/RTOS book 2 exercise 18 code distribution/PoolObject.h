/* 
  File name: PoolObject.h
  Version: 2.0   Date: 19/12/20  Author: JEC
	WARNING: Non-portable code.
*/

#ifndef PoolObject_H
#define PoolObject_H


#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "LedsAndPB.h"

typedef int  TaskColour;

#define Green 1
#define Red 2
/* ========================================================== */

void  PO_SetFlashingRate(int TaskColour, int FlashRate); 

void  PO_GetFlashingRate(int TaskColour, int* FlashRateRef); 

#endif

/* ======================================================================  */
