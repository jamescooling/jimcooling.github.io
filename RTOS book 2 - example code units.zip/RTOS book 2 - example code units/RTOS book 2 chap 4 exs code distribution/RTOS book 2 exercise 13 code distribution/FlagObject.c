 /*
  File name: FlagObject.c
  Version: 2.0   Date: 15/12/20  Author: JEC
*/

#include "FlagObject.h"
// IMPORTANT NOTE - THESE ITEMS NEED TO BE DECLARED AT FILE LEVEL
static Flag    CoordinatingFlag1 = Reset;
static Flag    CoordinatingFlag2 = Reset;
/*----------------------------------------------------------------------------*/

void FO_SetCoordinatingFlag1(void)
{
	CoordinatingFlag1 = Set;
    
} /*end FO_SetCoordinatingFlag1 */
////////////////////////////////////////////////////////////////////////////////

void FO_SetCoordinatingFlag2(void)
{
    CoordinatingFlag2 = Set;
    
} /*end FO_SetCoordinatingFlag2 */
////////////////////////////////////////////////////////////////////////////////

void FO_ResetCoordinatingFlag1(void)
{
    CoordinatingFlag1 = Reset;
    
} /*end FO_ResetCoordinatingFlag1 */
////////////////////////////////////////////////////////////////////////////////

void FO_ResetCoordinatingFlag2(void)
{
    CoordinatingFlag2 = Reset;
    
} /*end FO_ResetCoordinatingFlag2 */
////////////////////////////////////////////////////////////////////////////////

Flag FO_StatusOfCoordinatingFlag1(void)
{
    return CoordinatingFlag1;
    
} /*end FO_ResetCoordinatingFlag1 */
////////////////////////////////////////////////////////////////////////////////

Flag FO_StatusOfCoordinatingFlag2(void)
{
    return CoordinatingFlag2;
    
} /*end FO_ResetCoordinatingFlag2 */
////////////////////////////////////////////////////////////////////////////////



