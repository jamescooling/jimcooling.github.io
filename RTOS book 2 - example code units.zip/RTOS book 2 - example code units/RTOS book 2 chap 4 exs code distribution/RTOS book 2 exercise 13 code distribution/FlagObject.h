/* 
  File name: FlagObject.h 
  Version: 2.0   Date: 15/12/20  Author: JEC
*/

#ifndef FlagObject_H
#define FlagObject_H

#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"

typedef enum {Set, Reset} Flag;

void FO_SetCoordinatingFlag1(void);
void FO_SetCoordinatingFlag2(void);
void FO_ResetCoordinatingFlag1(void);
void FO_ResetCoordinatingFlag2(void);

Flag FO_StatusOfCoordinatingFlag1(void);
Flag FO_StatusOfCoordinatingFlag2(void);
#endif


