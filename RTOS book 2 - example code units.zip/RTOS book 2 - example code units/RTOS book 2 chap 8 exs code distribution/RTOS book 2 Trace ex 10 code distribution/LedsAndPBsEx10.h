/*
 File name: LedsAndPBsEX9.h
 Version: 2.0   Date: 29/4/20  Author: JEC
 */

#ifndef LedsAndPBs_H
#define LedsAndPBs_H

#include "main.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"

#define ToggleRedLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_14))
#define ToggleBlueLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15))
#define ToggleGreenLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_12))
#define ToggleOrangeLed (HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_13))

#define TurnRedLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_SET))
#define TurnBlueLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_SET))
#define TurnGreenLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET))
#define TurnOrangeLedOn  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET))

#define TurnRedLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_RESET))
#define TurnBlueLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_RESET))
#define TurnGreenLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET))
#define TurnOrangeLedOff  (HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET))

//#define GPIO_PinState UserPushButtonState;
#define ButtonReleased (UserPushButtonState == GPIO_PIN_RESET)
#define ButtonPressed (UserPushButtonState == GPIO_PIN_SET)
#define GetUserPBstatus (UserPushButtonState = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0))


#endif


