 /* 
  File name: MailboxModule.c
  Version: 2.0   Date: 31/12/20  Author: JEC
*/

#include "MailboxModule.h"

/* ==== NOTE NOTE NOTE == MODULE GLOBALS == GLOBALS GLOBALS ==== */

enum MBstate {MBnotCreated, MBcreated};
static enum MBstate    GlobalMailBoxState = MBnotCreated;

const int GlobalMBqueueLength 		= 1;
const int GlobalMBqueueItemSize 	= 4;	

/* Definition of the mutex, semaphores, and queue */
xSemaphoreHandle 	GlobalMBqueueMutex 	= NULL;
xSemaphoreHandle 	GlobalMBSemaSync1 	= NULL;
xSemaphoreHandle 	GlobalMBSemaSync2 	= NULL;
xQueueHandle 		GlobalMBqueue       = NULL;
/* === EndGlobals EndGlobals EndGlobals EndGlobals EndGlobals === */
/* ========================================================================== */
/* ========================================================================== */

void CreateGlobalmailMBox (void)
{
	/* Globals used here:
	GlobalMBSemaSync1
	GlobalMBSemaSync2
	GlobalMBSemaSync1State
	GlobalMBSemaSync2State
	GlobalMBqueueMutex
	GlobalGlobalMBQLength
	GlobalGlobalMBQItemSize 
	*/	
	#define Blocked  	1
	#define NoWaiting 0
	int QueueData;
	
	/* Create the mutex */
	GlobalMBqueueMutex = xSemaphoreCreateMutex();	
	
	/* Create the semaphores */
	vSemaphoreCreateBinary (GlobalMBSemaSync1);
	vSemaphoreCreateBinary (GlobalMBSemaSync2);
	
	/*Initialize the semaphores to a blocked state */
	xSemaphoreTake (GlobalMBSemaSync1, Blocked);
	xSemaphoreTake (GlobalMBSemaSync2, Blocked);	
	
	/* Create the queue */
	GlobalMBqueue = xQueueCreate (GlobalMBqueueLength, GlobalMBqueueItemSize);
	
	/* Perform a dummy read to empty the queue */
	xQueueReceive (GlobalMBqueue, &QueueData, NoWaiting);
	GlobalMailBoxState = MBcreated;
} /* end CreateGlobalMailBox */ 
/* ========================================================================== */
/* ========================================================================== */


void MB_PostToMailbox (int OutgoingMessage)
{
   /* Globals used here:
   GlobalMBqueueMutex
   GlobalMBqueue
   GlobalMBSemaSync2
   */
	#define NoWaiting  0
	int SemaWaitingTime 	= 50000;
	int MutexWaitingTime 	= 50000;
 	
	/* Make sure the mailbox is created	*/
	if (GlobalMailBoxState == MBnotCreated)
	{
		CreateGlobalmailMBox();
	}/* end creation call */
	
	/* Send data to the queue */
	xSemaphoreTake (GlobalMBqueueMutex, MutexWaitingTime);  // lock mutex	
		xQueueSendToBack (GlobalMBqueue, &OutgoingMessage, NoWaiting);	
	xSemaphoreGive (GlobalMBqueueMutex ); // unlock mutex

	/* Synchronize with the other task */
	xSemaphoreGive (GlobalMBSemaSync2 ); // signal (release) semaphore 2
	xSemaphoreTake (GlobalMBSemaSync1, SemaWaitingTime); // wait on semaphore 1
} /* end MB_PostToMailbox */
/* ========================================================================== */


void MB_PendOnMailbox (int* pIncomingMessage)
{
    /* Globals used here:
     GlobalMBSemaSync1
     GlobalMBSemaSync2
     GlobalMBqueueMutex
     */
	#define NoWaiting 0	
	#define QueueDataOK pdPASS	
	int QueueReadResult = errQUEUE_EMPTY;
	int QueueData = 0;
	int SemaWaitingTime 	= 50000;
	int MutexWaitingTime 	= 50000;
	
	/* Make sure the mailbox is created	*/
	if (GlobalMailBoxState == MBnotCreated)
	{
		CreateGlobalmailMBox();
	}	/* end creation */
    /* Synchronize with the other task */
	xSemaphoreGive (GlobalMBSemaSync1 ); // signal (release) semaphore 1
	xSemaphoreTake (GlobalMBSemaSync2, SemaWaitingTime); // wait on semaphore 2
	// Get data from queue
	do
	{
	xSemaphoreTake (GlobalMBqueueMutex, MutexWaitingTime);  // lock mutex		
		QueueReadResult = xQueueReceive (GlobalMBqueue, &QueueData, NoWaiting);
	xSemaphoreGive (GlobalMBqueueMutex ); // unlock mutex		
	osDelay (100);
	}
	while (QueueReadResult == QueueDataOK);
    // Just belts and braces
	if (QueueReadResult != QueueDataOK)
	{
		*pIncomingMessage = QueueData;
	}
} /* end MB_PendOnMailbox  */
/* ========================================================================== */
/* ========================================================================== */

