 /* 
  File name: CommonVariables.c
  Version: 2.0   Date: 31/12/20  Author: JEC
*/

#include "CommonVariables.h"

traceHandle CV_PBsignalHandle = 0;

int CV_CommonTestVariable = 0;
int CV_LedState = 0;
