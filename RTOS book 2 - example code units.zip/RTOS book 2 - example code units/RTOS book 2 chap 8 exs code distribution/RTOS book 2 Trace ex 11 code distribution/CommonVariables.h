/* 
  File name: CommonVariables.h
  Version: 2.0   Date: 31/12/20  Author: JEC
*/

#ifndef CommonVariables_H
#define CommonVariables_H

#include "main.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "trcRecorder.h"

extern traceHandle CV_PBsignalHandle;

extern int CV_CommonTestVariable;
extern int CV_LedState;


#endif


