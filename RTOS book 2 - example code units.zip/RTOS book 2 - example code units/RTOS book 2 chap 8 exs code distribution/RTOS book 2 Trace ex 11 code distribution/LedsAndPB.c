 /* 
  File name: LedsAndPB.c
  Version: 2.0   Date: 31/12/20  Author: JEC
*/
#include "LedsAndPB.h"

void DebounceSwitchSignal (void)
{
    int PBpressedCount;
    int LoopCount = 0;
    GPIO_PinState   CurrentPBstate;// = 0;
    
    PBpressedCount = 0;
    while (PBpressedCount < 5)
    {
        CurrentPBstate = UserPBstatus;
        if (CurrentPBstate == ButtonIsPressed)
        {
            PBpressedCount++;
        }
        else
        {
            PBpressedCount = 0;
        }
        // This is a short delay - 40,000,000 is approx. 1 second
        // end if else
        for (LoopCount=0; LoopCount<1000000; LoopCount++)// approx 50 mSec
        {;}
    }
    /* end while */
} // end DebounceSwitchSignal
