 /* 
  File name:    EFSema1Object.c
  Version: 2.0   Date: 31/12/20  Author: JEC
*/

#include "EFSema1Object.h"

/* ==== NOTE NOTE NOTE == MODULE GLOBALS == GLOBALS GLOBALS ==== */

#define WaitForever		portMAX_DELAY
#define Blocked  	1
#define NoWaiting 0

enum SemaState {SemaNotCreated, SemaCreated};
static enum SemaState    EFSemaState = SemaNotCreated;
/* === EndGlobals EndGlobals EndGlobals EndGlobals EndGlobals === */

/* Definition of the semaphore */
xSemaphoreHandle    EFSema1 	= NULL;

/* ========================================================================== */
/* ========================================================================== */

void CreateEFSema1 (void)
{
	/* Create the semaphores */
	vSemaphoreCreateBinary (EFSema1);	
	EFSemaState = SemaCreated;
	/*Initialize the semaphores to a blocked state */
	xSemaphoreTake (EFSema1, Blocked);
} /* end CreateEFSema */
/* ========================================================================== */
/* ========================================================================== */

void SetEFSema1 (void)
{
	if (EFSemaState == SemaNotCreated)
	{
		CreateEFSema1();
	}
	xSemaphoreGiveFromISR (EFSema1, NULL);	
		TurnBlueLedOn;
} /* end SetEFSema */
/* ========================================================================== */


void WaitEFSema1 (void)
{
	if (EFSemaState == SemaNotCreated)
	{
		CreateEFSema1();
	}	
	xSemaphoreTake (EFSema1, WaitForever); 	// wait on semaphore 1      
} /* end WaitEFSema  */
/* ========================================================================== */
